// Import p5.js and define the sketch
new p5((sketch) => {
  let f = 0; // Animation variable for dynamic movements
  let canvasSize; // Variable to store canvas size for responsiveness

  // Define numbers and their weights for different animation speeds
  const numbers = [
    { name: "Low", weight: 10, increment: sketch.PI / 4 },
    { name: "Mid", weight: 60, increment: sketch.PI / 10 },
    { name: "High", weight: 15, increment: sketch.PI / 60 },
    { name: "Extreme", weight: 5, increment: sketch.PI / 500 },
  ];

  // Define color palettes and their weights
  const colorPalettes = [
    // 8bit palette
    {
      name: "8bit",
      weight: 20,
      colors: {
        bg: "#000000",
        outerDots: "#FF0000",
        middleDots: "#00FF00",
        innerDots: "#0000FF",
      },
    },
    // Vampire palette
    {
      name: "Vampire",
      weight: 20,
      colors: {
        bg: "#290001",
        outerDots: "#630000",
        middleDots: "#AA0000",
        innerDots: "#FF0000",
      },
    },
    // Hacker palette
    {
      name: "Hacker",
      weight: 20,
      colors: {
        bg: "#0F3D0F",
        outerDots: "#127212",
        middleDots: "#00FF00",
        innerDots: "#ADEBAD",
      },
    },
    // BlueSky palette
    {
      name: "BlueSky",
      weight: 20,
      colors: {
        bg: "#87CEEB",
        outerDots: "#4682B4",
        middleDots: "#B0C4DE",
        innerDots: "#F0F8FF",
      },
    },
    // Monochrome palette
    {
      name: "Monochrome",
      weight: 20,
      colors: {
        bg: "#000000",
        outerDots: "#333333",
        middleDots: "#666666",
        innerDots: "#FFD700",
      },
    },
  ];

  // Function to randomly select based on weights, using fx(hash) randomness
  function weightedRandomSelection(options) {
    let totalWeight = options.reduce(
      (total, option) => total + option.weight,
      0
    );
    let random = $fx.rand() * totalWeight;
    for (let i = 0; i < options.length; i++) {
      if (random < options[i].weight) {
        return options[i];
      }
      random -= options[i].weight;
    }
    return options[0];
  }

  // Select a number and a color palette randomly
  const selectedNumber = weightedRandomSelection(numbers);
  const selectedPalette = weightedRandomSelection(colorPalettes);

  // Report selected features
  $fx.features({
    Numbers: selectedNumber.name,
    ColorPalette: selectedPalette.name,
  });

  // Setup sketch
  sketch.setup = function () {
    canvasSize = sketch.min(sketch.windowWidth, sketch.windowHeight);
    sketch.createCanvas(canvasSize, canvasSize);
    sketch.stroke(255);
    sketch.loop();
  };

  // Handle window resizing
  sketch.windowResized = function () {
    canvasSize = sketch.min(sketch.windowWidth, sketch.windowHeight);
    sketch.resizeCanvas(canvasSize, canvasSize);
  };

  // Draw function for animations
  sketch.draw = function () {
    sketch.background(selectedPalette.colors.bg);
    let centerX = canvasSize / 2;
    let centerY = canvasSize / 2;
    let maxRadius = canvasSize / 2.35;

    for (let i = 0; i < sketch.TAU; i += selectedNumber.increment) {
      let r = maxRadius / 2;
      let x = sketch.sin(f + i) * r + centerX;
      let y = sketch.cos(f + i) * r + centerY;
      sketch.fill(selectedPalette.colors.innerDots);
      sketch.circle(x, y, canvasSize * 0.015);

      r = maxRadius;
      let X = sketch.sin(f + i) * r + centerX;
      let Y = sketch.cos(f + i) * r + centerY;
      X = sketch.constrain(X, centerX - maxRadius / 2, centerX + maxRadius / 2);
      Y = sketch.constrain(Y, centerY - maxRadius / 2, centerY + maxRadius / 2);
      sketch.fill(selectedPalette.colors.middleDots);
      sketch.line(x, y, X, Y);
      sketch.circle(X, Y, canvasSize * 0.015);

      x = sketch.sin(f + i) * r + centerX;
      y = sketch.cos(f + i) * r + centerY;
      sketch.fill(selectedPalette.colors.outerDots);
      sketch.line(x, y, X, Y);
      sketch.circle(x, y, canvasSize * 0.015);
    }

    f += 0.01; // Increment the frame animation variable
  };
});

function updateDOM() {
  // Update DOM only if necessary or during specific interactions
  const bgcolor = "#000000"; // Using a fixed background for simplicity
  const textcolor = "#ffffff";
  document.body.style.background = bgcolor;
  document.body.innerHTML = `
    <div style="color: ${textcolor};">
      <p>hash: ${$fx.hash}</p>
      <p>minter: ${$fx.minter}</p>
      <p>iteration: ${$fx.iteration}</p>
      <p>inputBytes: ${$fx.inputBytes}</p>
      <p>context: ${$fx.context}</p>
      <p>params:</p>
      <pre>${$fx.stringifyParams($fx.getRawParams())}</pre>
    </div>
  `;
}
